<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home page</title>
<link href="homepage.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<?php
include("header.php")
?>
    
    
    <div class="banner"></div>
    <p class = "paragraph">
    Lorem ipsum, dolor sit amet consectetur adipisicing elit.<br>
     Ullam assumenda quo enim iure amet iusto natus omnis fuga<br>
      ipsa beatae nobis eaque, praesentium perferendis<br>
       perspiciatis odio nihil eligendi ratione vero.<br>
   </p>
   <a href="product_page.php" class="shop-now-button">Shop Now</a><br>
   <h1 align ="center">Shop by Category</h1>
   <div class="product-container">
        <a href="butchers.php" class="product">
            <img src="product.jpg" alt="Product">  
            BUTCHERS
        </a>

        <a href="greengrocer.php" class="product">
            <img src="product.jpg" alt="Product"> 
            GREENGROCER 
        </a>

        <a href="fishmonger.php" class="product">
            <img src="product.jpg" alt="Product"> 
            FISHMONGER 
        </a>

        <a href="bakery.php" class="product">
            <img src="product.jpg" alt="Product"> 
            BAKERY 
        </a>

        <a href="delicatessen.php" class="product">
            <img src="product.jpg" alt="Product"> 
            DELICATESSEN 
        </a>

    </div>
    <br>
 
    <h1 align ="center">See What's New</h1>


   <div class="product-container2">
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>          
</div>
</div>
<br>
<h1 align ="center">Fam Favortes!</h1>
<div class="product-container">
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
            

        <div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
</div>
            



    </body>
    </html>