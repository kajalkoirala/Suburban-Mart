<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in and Sign up</title>
</head>
<body>
<form method="POST" action="login.php">
    <legend>
        <fieldset>Welcome!</fieldset>
        Sign in to your Account<br><br>
        <input type="text" name ="username" placeholder="Username"><br><br>
        <input type="password" name="password" placeholder="Password"><br><br>
        Role: <option value="role"></option>
        <select name="role" id="">
            <option value="Trader">Trader</option>
            <option value="Customer">Customer</option>
        </select><br><br>
        <input type="checkbox" name="checkbox">Remember me<br><br>
        <input type="submit" name="login"><br><br><br><br>
    </legend>
</form>

<form method="POST" action="register.php"> 
    <legend>
        <fieldset>Create Account</fieldset><br>
        Role: <option value="role"></option>
        <select name="role" id="">
            <option value="Trader">Trader</option>
            <option value="Customer">Customer</option>
        </select><br><br>
        <input type="text" name="firstname" placeholder="Firstname"><br><br>
        <input type="text" name="middlename" placeholder="Middlename"><br><br>
        <input type="text" name="lastname" placeholder="Lastname"><br><br>
        Age:<option value="">Age</option>
        <select name="age" id="">
            <?php
            for ($i = 1; $i <= 100; $i++) {
                echo "<option value='$i'>$i</option>";
            }
            ?>
        </select><br><br>
        <input type="number" name="phone" placeholder="Contact"><br><br>
        <input type="email" name="email" placeholder="Email"><br><br>
        <input type="text" name="username" placeholder="Username"><br><br>
        <input type="password" name="password" placeholder="Password"><br><br>
        <input type="submit" name="submit" placeholder="Create"><br><br>
    </legend>
</form>



</body>
</html>
