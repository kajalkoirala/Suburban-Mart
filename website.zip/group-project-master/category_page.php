<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Category page</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Category page</title>
<link href="categorypage.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<?php
include("header.php")
?>

<div class="banner"></div>
<h1 align="center">Category</h1>
<div class="product-container">

  <a href="butchers.php" class="product">
        <img src="images/product.jpg" alt="Product">  
        BUTCHERS
    </a>

    <a href="greengrocer.php" class="product">
        <img src="images/product.jpg" alt="Product"> 
        GREENGROCER 
    </a>

    <a href="fishmonger.php" class="product">
        <img src="images/product.jpg" alt="Product"> 
        FISHMONGER 
    </a>

    <a href="bakery.php" class="product">
        <img src="images/product.jpg" alt="Product"> 
        BAKERY 
    </a>

    <a href="delicatessen.php" class="product">
        <img src="images/product.jpg" alt="Product"> 
        DELICATESSEN 
    </a>

</div>


</body>
</html>
