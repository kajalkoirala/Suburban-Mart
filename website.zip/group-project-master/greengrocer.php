<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Product page</title>
<link href="productpage.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<?php
include("header.php")
?>

  
    <div class="banner"></div>
    <div class="rectangle">
    <div class="search-bar">
            <input type="text" placeholder="Search...">
            <button><i class="fas fa-search"></i></button>
        </div>
        <div class="dropdowns">
            <div class="dropdown">
                <button class="dropbtn">Price</button>
                <div class="dropdown-content">
                    <a href="#">High to Low</a>
                    <a href="#">Low to High</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="dropbtn">Sort by</button>
                <div class="dropdown-content">
                    <a href="#">A-Z</a>
                    <a href="#">Z-A</a>
                    <a href="#">Ratings</a>
                </div>
            </div>
        </div>
    </div>
    <div class="product-container">
        <div class="product">
            <img src="images/GreenGrocer/carrot.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>

        <div class="product-container">
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product-container">
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>

    </div>
    <script src="script.js"></script>


    
</body>
</html>
