<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="homepage.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="style.css" />
    <title>Profile Dropdown</title>
  </head>
  <body>
    <nav class="navbar">
      <img src="images/LOGO.png" class="navbar-logo" alt="logo" />
      <ul class="navbar-list">
      <li><a href="guesthome.php">HOME</a></li>
        <li><a href="guestcategory.php">CATEGORIES</a></li>
        <li><a href="guestproduct.php">ALL PRODUCTS</a></li>
      </ul>

      <div class="box">
        <input type="checkbox" id="check">
        <div class="search-box">
          <input type="text" placeholder="Search Products...">
          <label for="check" class="icon">
            <i class="fas fa-search"></i>
          </label>
        </div>
      </div>

      <div class="profile-dropdown">
        <div onclick="toggle()" class="profile-dropdown-btn">
          <div class="profile-img">
            <i class="fa-solid fa-circle"></i>
          </div>

          <span
            >Guest
            <i class="fa-solid fa-angle-down"></i>
          </span>
        </div>

        <ul class="profile-dropdown-list">

          <li class="profile-dropdown-list-item">
            <a href="#">
              <i class="fa fa-shopping-cart"></i>
              Cart
            </a>
          </li>

          <hr />

          <li class="profile-dropdown-list-item">
            <a href="#">
              <i class="fa fa-sign-in"></i>
              Log In
            </a>
          </li>
        </ul>
      </div>
    </nav>

    <script src="script.js"></script>
    <div class="banner"></div>
    <p class = "paragraph">
    Lorem ipsum, dolor sit amet consectetur adipisicing elit.<br>
     Ullam assumenda quo enim iure amet iusto natus omnis fuga<br>
      ipsa beatae nobis eaque, praesentium perferendis<br>
       perspiciatis odio nihil eligendi ratione vero.<br>
   </p>
   <a href="guestproduct.php" class="shop-now-button">Shop Now</a><br>
   <h1 align ="center">Shop by Category</h1>
   <div class="product-container">
        <a href="butchers.php" class="product">
            <img src="product.jpg" alt="Product">  
            BUTCHERS
        </a>

        <a href="greengrocer.php" class="product">
            <img src="product.jpg" alt="Product"> 
            GREENGROCER 
        </a>

        <a href="fishmonger.php" class="product">
            <img src="product.jpg" alt="Product"> 
            FISHMONGER 
        </a>

        <a href="bakery.php" class="product">
            <img src="product.jpg" alt="Product"> 
            BAKERY 
        </a>

        <a href="delicatessen.php" class="product">
            <img src="product.jpg" alt="Product"> 
            DELICATESSEN 
        </a>

    </div>
 
    <h1 align ="center">See What's New</h1>


   <div class="product-container2">
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product2">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>          
</div>
</div>
<h1 align ="center">Fam Favortes!</h1>
<div class="product-container">
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
            

        <div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<div class="product3">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="rating">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
    </div>
</div>
</div>
            



    </body>
    </html>
  </body>
</html>
