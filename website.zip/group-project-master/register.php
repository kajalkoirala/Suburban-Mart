<?php
include("connection.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
function send_mail($email,$v_code)
{
    require ("PHPMailer/PHPMailer.php");
    require ("PHPMailer/Exception.php");
    require ("PHPMailer/SMTP.php");

    $mail = new PHPMailer(true);
    try {
                          
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                    
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = 'koko.mitsuu@gmail.com';                    
        $mail->Password   = 'mclj zhdw sxnc syht';                               
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
        $mail->Port       = 465;                                    
    
  
        $mail->setFrom('koko.mitsuu@gmail.com', 'Submart');
        $mail->addAddress($email);     
        
 
        $mail->isHTML(true);                                 
        $mail->Subject = 'Email verification from SubMart';
        $mail->Body    = "Thankyou for registration. 
        Click the link below to verify the email address.
        <a href='http://localhost/teamproject/verify.php?email=$email&v_code=$v_code'>Verify </a>";
        
    
        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }

    
}



if(isset($_POST["submit"]))
{
    $role = $_POST["role"];
    $firstname = trim($_POST["firstname"]);
    $middlename= trim($_POST["middlename"]);
    $lastname = trim($_POST["lastname"]);
    $age = $_POST["age"];
    $contact = $_POST["phone"];
    $email = $_POST["email"];
    $username= $_POST["username"];
    $password = md5($_POST["password"]);

    if(empty($firstname) || empty($lastname) || empty($age) || empty($contact) || empty($email) || empty($username) || empty($password))
     {
        echo "All fields should be filled.";
        exit;
    }

    // if(strlen($password) < 8 || !preg_match("/[a-z]/", $password) || !preg_match("/[A-Z]/", $password) || !preg_match("/[!@#\$%\^&\*]/", $password)) 
    // {
    //     echo "Password should be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one special character.";
    //     exit;
    // }


    $v_code = bin2hex(random_bytes(16));
    $sql = "INSERT INTO user(first_name,middle_name,last_name,age,phone,email,username,password,role,verification_code,is_verified) VALUES ('$firstname','$middlename','$lastname' ,'$age', '$contact', '$email', '$username', '$password','$role','$v_code','0')";
    // $qry = mysqli_query($conn, $sql) or die (mysqli_error($conn));
    if(mysqli_query($conn, $sql) && send_mail($_POST['email'],$v_code) )
    {
        echo "Data inserted successfully";
        if($role == "Trader")
        {
            echo "<script>window.location.href = 'traderlogin.php';</script>";
            exit;
        }
    }
    else
    {
        echo "Cannot execute"; 
    }

}

?>