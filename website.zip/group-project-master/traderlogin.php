<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trader login</title>
</head>
<body>
    <form method="POST" action="" enctype="multipart/form-data">
        <legend>
            <fieldset>Trader</fieldset>
            <input type="text" name="shopname" placeholder="Shop name"><br><br>
            <textarea name="description" placeholder="Shop Description"></textarea><br><br>
            <input type="text" name="category" placeholder="Product Category"><br><br>
            <input type="file" name="image" accept="image/*"><br><br>
            <input type="submit" name="register">
        </legend>
    </form>
    <?php
include("connection.php");

if(isset($_POST["register"]))
{
    $shopname = $_POST["shopname"];
    $description = $_POST["description"];
    $category= $_POST["category"];
    $image = $_FILES["image"]["name"]; 
    $image_folder = "uploads/";
    $image_file = $image_folder . basename($_FILES["image"]["name"]);
    move_uploaded_file($_FILES["image"]["tmp_name"], $image_file);

    $sql = "INSERT INTO trader(shop_name, shop_description, product_category, image) VALUES ('$shopname', '$description', '$category', '$image')";
    $qry = mysqli_query($conn, $sql) or die (mysqli_error($conn));
    if($qry)
    {
        
        echo "<script>window.location.href = 'sign_in_up.php';</script>";
    }
    else
    {
        echo "Cannot execute"; 
    }
}
?>
</body>
</html>