<?php
include("connection.php");
if(isset($_POST["login"]))
{
    $username = $_POST["username"];
    $password = $_POST["password"];
    $role = $_POST["role"];
    

    $sql1 = "SELECT * from user where username = '$username' and password = '$password' and role = '$role'";
    $qry1 = mysqli_query($conn , $sql1) or die(mysqli_error($conn));
    $row = mysqli_fetch_assoc($qry1);

    if ($row) {
        
        if ($role == "Trader") 
        {
            header('location: trader.php');
            exit;
       
        } 
        elseif ($role == "Customer") 
        {
          
            header('location: customer.php');
            exit;
          
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in and Sign up</title>
</head>
<body>
<form method="POST" action="">
    <legend>
        <fieldset>Welcome!</fieldset>
        Sign in to your Account<br><br>
        <input type="text" name ="username" placeholder="Username"><br><br>
        <input type="password" name="password" placeholder="Password"><br><br>
        Role: <option value="role"></option>
        <select name="role" id="">
            <option value="Trader">Trader</option>
            <option value="Customer">Customer</option>
        </select><br><br>
        <input type="checkbox" name="checkbox">Remember me<br><br>
        <input type="submit" name="login"><br><br><br><br>
    </legend>
</form>

<form method="POST" action=""> 
    <legend>
        <fieldset>Create Account</fieldset><br>
        Role: <option value="role"></option>
        <select name="role" id="">
            <option value="Trader">Trader</option>
            <option value="Customer">Customer</option>
        </select><br><br>
        <input type="text" name="firstname" placeholder="Firstname"><br><br>
        <input type="text" name="middlename" placeholder="Middlename"><br><br>
        <input type="text" name="lastname" placeholder="Lastname"><br><br>
        Age:<option value="">Age</option>
        <select name="age" id="">
            <?php
            for ($i = 1; $i <= 100; $i++) {
                echo "<option value='$i'>$i</option>";
            }
            ?>
        </select><br><br>
        <input type="number" name="phone" placeholder="Contact"><br><br>
        <input type="email" name="email" placeholder="Email"><br><br>
        <input type="text" name="username" placeholder="Username"><br><br>
        <input type="password" name="password" placeholder="Password"><br><br>
        <input type="submit" name="submit" placeholder="Create"><br><br>
    </legend>
</form>

<?php
if(isset($_POST["submit"]))
{
    $role = $_POST["role"];
    $firstname = $_POST["firstname"];
    $middlename= $_POST["middlename"];
    $lastname = $_POST["lastname"];
    $age = $_POST["age"];
    $contact = $_POST["phone"];
    $email = $_POST["email"];
    $username= $_POST["username"];
    $password = $_POST["password"];

    $sql = "INSERT INTO user(first_name,middle_name,last_name,age,phone,email,username,password,role) VALUES ('$firstname','$middlename','$lastname' ,'$age', '$contact', '$email', '$username', '$password','$role')";
    $qry = mysqli_query($conn, $sql) or die (mysqli_error($conn));
    if($qry)
    {
        echo "Data inserted successfully";
        if($role == "Trader")
        {
            echo "<script>window.location.href = 'traderlogin.php';</script>";
            exit;
        }
    }
    else
    {
        echo "Cannot execute"; 
    }

}

?>

</body>
</html>
