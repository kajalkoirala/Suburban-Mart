<?php
$h = "localhost";
$u = "root";
$p = "root";
$db = "teamproject";
$conn = mysqli_connect($h,$u,$p,$db);
if(!$conn)
{
    echo"Database not connected";
}

?>