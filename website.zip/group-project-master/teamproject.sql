-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 25, 2024 at 04:05 PM
-- Server version: 5.7.39
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teamproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `trader`
--

CREATE TABLE `trader` (
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updates_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `shop_name` varchar(255) NOT NULL,
  `shop_description` varchar(255) NOT NULL,
  `product_category` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `trader_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trader`
--

INSERT INTO `trader` (`date_added`, `updates_date`, `shop_name`, `shop_description`, `product_category`, `image`, `trader_id`) VALUES
('2024-03-25 15:57:35', '2024-03-25 15:57:35', 'abcd', 'wqewq', 'wqdwqd', 'IMG_3156.JPG', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(6) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `middle_name` varchar(40) DEFAULT NULL,
  `last_name` varchar(30) NOT NULL,
  `age` int(20) NOT NULL,
  `phone` bigint(255) NOT NULL,
  `email` varchar(55) NOT NULL,
  `username` varchar(55) NOT NULL,
  `password` varchar(55) NOT NULL,
  `role` varchar(10) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `middle_name`, `last_name`, `age`, `phone`, `email`, `username`, `password`, `role`, `created_on`, `update_date`) VALUES
(2, 'Shreeja', '', 'Neupane', 20, 9863858636, 'shreeja@gmail.com', 'shreeja033', '12345', 'Customer', '2024-03-25 14:54:22', '2024-03-25 14:54:22'),
(6, 'Shreeya', '', 'Neupane', 3, 342324, 'aa@gmail.com', 'shreeyaa', '12345', 'Trader', '2024-03-25 15:13:41', '2024-03-25 15:13:41'),
(7, 'Purnima', '', 'Dangol', 20, 9847778571, 'pdangol@gmail.com', 'pdangol', '12345', 'Trader', '2024-03-25 15:57:19', '2024-03-25 15:57:19'),
(8, 'Saujanya', '', 'Neupane', 15, 9811111111, 'saujanya@gmail.com', 'saujanyaa', '12345', 'Customer', '2024-03-25 15:58:55', '2024-03-25 15:58:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `trader`
--
ALTER TABLE `trader`
  ADD PRIMARY KEY (`trader_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `unique` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `trader`
--
ALTER TABLE `trader`
  MODIFY `trader_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
