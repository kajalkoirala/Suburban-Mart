<?php
include("connection.php");
if(isset($_POST["login"]))
{
    $username = $_POST["username"];
    $password = $_POST["password"];
    $role = $_POST["role"];

    $sql1 = "SELECT * from user where username = '$username' and password = '$password' and role = '$role'";
    
    $qry1 = mysqli_query($conn , $sql1) or die(mysqli_error($conn));
    $row = mysqli_fetch_assoc($qry1);

    if ($row) {
        if ($row['is_verified'] == '0') {
            echo "You've not been verified yet.";
        } else {
            if ($role == "Trader") {
                header('location: trader.php');
                exit;
            } elseif ($role == "Customer") {
                header('location: homepage.php');
                exit;
            }
        }
    } else {
        echo "You've not registered. Please create account first.";
    }
}
?>
