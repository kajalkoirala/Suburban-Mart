<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="productpage.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="style.css" />
    <title>Product page</title>
  </head>
  <body>
    <nav class="navbar">
      <img src="images/LOGO.png" class="navbar-logo" alt="logo" />
      <ul class="navbar-list">
      <li><a href="guesthome.php">HOME</a></li>
        <li><a href="guestcategory.php">CATEGORIES</a></li>
        <li><a href="guestproduct.php">ALL PRODUCTS</a></li>
      </ul>

      <div class="box">
        <input type="checkbox" id="check">
        <div class="search-box">
          <input type="text" placeholder="Search Products...">
          <label for="check" class="icon">
            <i class="fas fa-search"></i>
          </label>
        </div>
      </div>

      <div class="profile-dropdown">
        <div onclick="toggle()" class="profile-dropdown-btn">
          <div class="profile-img">
            <i class="fa-solid fa-circle"></i>
          </div>

          <span
            >Guest
            <i class="fa-solid fa-angle-down"></i>
          </span>
        </div>

        <ul class="profile-dropdown-list">

          <li class="profile-dropdown-list-item">
            <a href="#">
              <i class="fa fa-shopping-cart"></i>
              Cart
            </a>
          </li>

          <hr />

          <li class="profile-dropdown-list-item">
            <a href="#">
              <i class="fa fa-sign-in"></i>
              Log In
            </a>
          </li>
        </ul>
      </div>
    </nav>

   
    <div class="banner"></div>
    <div class="rectangle">
    <div class="search-bar">
            <input type="text" placeholder="Search...">
            <button><i class="fas fa-search"></i></button>
        </div>
        <div class="dropdowns">
            <div class="dropdown">
                <button class="dropbtn">Price</button>
                <div class="dropdown-content">
                    <a href="#">High to Low</a>
                    <a href="#">Low to High</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="dropbtn">Sort by</button>
                <div class="dropdown-content">
                    <a href="#">A-Z</a>
                    <a href="#">Z-A</a>
                    <a href="#">Ratings</a>
                </div>
            </div>
        </div>
    </div>
    <div class="product-container">
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>

        <div class="product-container">
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product-container">
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="product">
            <img src="product.jpg" alt="Product ">
            <div class="details">
                <p class="name">Product Name </p>
                <p class="price">$10.00</p>
                <div class="buttons">
                    <button class="wishlist-button"><i class="far fa-heart"></i></button>
                    <button class="add-to-cart-button">Add to Cart</button>
                </div>
            </div>
        </div>

    </div>
    <script src="script.js"></script>


    
</body>
</html>
